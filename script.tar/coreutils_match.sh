#!/bin/bash

SBRIDGE_PATH="/home/user/SBridge/bin/Release/net9.0/sbridge"
DATASET_PATH="/home/user/dataset/RQ1/coreutils/"

if [ "$#" -eq 0 ]; then
    echo "Usage: $0 command1 command2 ... commandN"
    exit 1
fi

for cmd in "$@"; do
    echo "Executing: $SBRIDGE_PATH -m $DATASET_PATH$cmd"
    $SBRIDGE_PATH -m "$DATASET_PATH$cmd"
done