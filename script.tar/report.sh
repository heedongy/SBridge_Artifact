#!/bin/bash

DATASET_PATH="/home/user/dataset/RQ1"

# Collect all CSV rows from coreutils and inetutils
TMP=$(mktemp /tmp/sbridge_rq1_all.XXXXXX)

for project in coreutils inetutils; do
    for csv in "$DATASET_PATH/$project"/*/SBridge_matching_result.csv; do
        if [ -f "$csv" ]; then
            cat "$csv" >> "$TMP"
        fi
    done
done

if [ ! -s "$TMP" ]; then
    echo "[!] No SBridge_matching_result.csv files found under $DATASET_PATH"
    rm -f "$TMP"
    exit 1
fi

# Aggregate and print results using awk
awk -F',' '
{
    binaryFile = $1
    testCount  = $2 + 0
    tp1        = $4 + 0
    tp5        = $5 + 0
    mrrSum     = $20 + 0

    if (testCount == 0) next

    # ---- Architecture ----
    arch = "unknown"
    if      (binaryFile ~ /_arm_32_/) arch = "ARM32"
    else if (binaryFile ~ /_arm_64_/) arch = "ARM64"
    else if (binaryFile ~ /_x86_64_/) arch = "x64"
    else if (binaryFile ~ /_x86_/)    arch = "x86"

    # ---- Compiler ----
    compiler = "unknown"
    if      (binaryFile ~ /_gcc-/)   compiler = "GCC"
    else if (binaryFile ~ /_clang-/) compiler = "Clang"

    # ---- Optimization ----
    opt = "unknown"
    if      (binaryFile ~ /_O0_/) opt = "O0"
    else if (binaryFile ~ /_O1_/) opt = "O1"
    else if (binaryFile ~ /_O2_/) opt = "O2"
    else if (binaryFile ~ /_O3_/) opt = "O3"
    else if (binaryFile ~ /_Os_/) opt = "Os"

    # ---- Strip status ----
    strip_status = "no_strip"
    if (binaryFile ~ /_strip$/) strip_status = "strip"

    # ---- Accumulate ----
    total_tp1 += tp1;  total_tp5 += tp5;  total_tc += testCount;  total_mrr += mrrSum

    arch_tp1[arch] += tp1;  arch_tp5[arch] += tp5;
    arch_tc[arch]  += testCount;  arch_mrr[arch] += mrrSum

    comp_tp1[compiler] += tp1;  comp_tp5[compiler] += tp5;
    comp_tc[compiler]  += testCount;  comp_mrr[compiler] += mrrSum

    opt_tp1[opt] += tp1;  opt_tp5[opt] += tp5;
    opt_tc[opt]  += testCount;  opt_mrr[opt] += mrrSum

    strip_tp1[strip_status] += tp1;  strip_tp5[strip_status] += tp5;
    strip_tc[strip_status]  += testCount;  strip_mrr[strip_status] += mrrSum
}
END {
    w1 = 10; w2 = 10; w3 = 10; w4 = 10

    sep = "+--------------+----------+----------+----------+"
    hdr = "| %-12s | %8s | %8s | %8s |"
    fmt = "| %-12s | %8.4f | %8.4f | %8.4f |"

    printf "\n"
    printf "  ============================================\n"
    printf "       SBridge  RQ1  Result  Report\n"
    printf "  ============================================\n"

    # --- By architecture ---
    printf "\n  [By architecture]\n"
    printf "  %s\n", sep
    printf "  " hdr "\n", "", "R@1", "R@5", "MRR"
    printf "  %s\n", sep
    for (a in arch_tc)
        if (arch_tc[a] > 0)
            printf "  " fmt "\n", a, arch_tp1[a]/arch_tc[a], arch_tp5[a]/arch_tc[a], arch_mrr[a]/arch_tc[a]
    printf "  %s\n", sep

    # --- By compiler ---
    printf "\n  [By compilers]\n"
    printf "  %s\n", sep
    printf "  " hdr "\n", "", "R@1", "R@5", "MRR"
    printf "  %s\n", sep
    for (c in comp_tc)
        if (comp_tc[c] > 0)
            printf "  " fmt "\n", c, comp_tp1[c]/comp_tc[c], comp_tp5[c]/comp_tc[c], comp_mrr[c]/comp_tc[c]
    printf "  %s\n", sep

    # --- By optimization ---
    printf "\n  [By optimizations]\n"
    printf "  %s\n", sep
    printf "  " hdr "\n", "", "R@1", "R@5", "MRR"
    printf "  %s\n", sep
    for (o in opt_tc)
        if (opt_tc[o] > 0)
            printf "  " fmt "\n", o, opt_tp1[o]/opt_tc[o], opt_tp5[o]/opt_tc[o], opt_mrr[o]/opt_tc[o]
    printf "  %s\n", sep

    # --- By symbol management ---
    printf "\n  [By symbol managements]\n"
    printf "  %s\n", sep
    printf "  " hdr "\n", "", "R@1", "R@5", "MRR"
    printf "  %s\n", sep
    for (s in strip_tc)
        if (strip_tc[s] > 0)
            printf "  " fmt "\n", s, strip_tp1[s]/strip_tc[s], strip_tp5[s]/strip_tc[s], strip_mrr[s]/strip_tc[s]
    printf "  %s\n", sep

    # --- Total ---
    printf "\n  [Total result (average)]\n"
    printf "  %s\n", sep
    printf "  " hdr "\n", "", "R@1", "R@5", "MRR"
    printf "  %s\n", sep
    if (total_tc > 0)
        printf "  " fmt "\n", "Total", total_tp1/total_tc, total_tp5/total_tc, total_mrr/total_tc
    printf "  %s\n\n", sep
}
' "$TMP"

rm -f "$TMP"
