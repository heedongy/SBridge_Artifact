#!/bin/bash
./SBridge/bin/Release/net9.0/sbridge -m dataset/sample/cat

