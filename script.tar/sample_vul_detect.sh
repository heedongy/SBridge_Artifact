#!/bin/bash
./SBridge/bin/Release/net9.0/sbridge -d dataset/sample/CVE-2022-40303

