#!/bin/bash

SBRIDGE_PATH="/home/user/SBridge/bin/Release/net9.0/sbridge"
DATASET_PATH="/home/user/dataset/RQ4/"

if [ "$#" -eq 0 ]; then
    echo "Usage: $0 CVE1 CVE2 ... CVEN"
    exit 1
fi

for cmd in "$@"; do
    echo "Executing: $SBRIDGE_PATH -d $DATASET_PATH$cmd"
    $SBRIDGE_PATH -d "$DATASET_PATH$cmd"
done